//array of student JSON details

let students = [
    {regno:'2021ict01',name:'Yeheni',gender:'Female'},
    {regno:'2021ict02',name:'Sashini',gender:'Female'},
    {regno:'2021ict03',name:'James',gender:'Male'},
    {regno:'2021ict04',name:'Ushani',gender:'Female'},
    {regno:'2021ict05',name:'Ridmi',gender:'Female'},
    {regno:'2021ict06',name:'Saman',gender:'Male'},
    {regno:'2021ict07',name:'Samodya',gender:'Female'},
    {regno:'2021ict08',name:'Ruwan',gender:'Male'}
    ];

    module.exports=students;