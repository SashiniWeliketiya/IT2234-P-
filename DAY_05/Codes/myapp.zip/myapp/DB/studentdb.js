//array of student JSON details

let students = [
    {regno:'2021ict01',name:'Yeheni',gender:'F'},
    {regno:'2021ict02',name:'Sashini',gender:'F'},
    {regno:'2021ict02',name:'Sewmini',gender:'F'},
    {regno:'2021ict03',name:'James',gender:'M'},
    {regno:'2021ict04',name:'Ushani',gender:'F'},
    {regno:'2021ict05',name:'Ridmi',gender:'F'},
    {regno:'2021ict06',name:'Saman',gender:'M'},
    {regno:'2021ict07',name:'Samodya',gender:'F'},
    {regno:'2021ict08',name:'Ruwan',gender:'M'}
    ];

    module.exports=students;