let users = [
    { id: '1', username: 'john_doe', email: 'john@example.com', fullName: 'John Doe' },
    { id: '2', username: 'alice_smith', email: 'alice@example.com', fullName: 'Alice Smith' },
    { id: '3', username: 'bob_jackson', email: 'bob@example.com', fullName: 'Bob Jackson' },
    { id: '4', username: 'emma_jones', email: 'emma@example.com', fullName: 'Emma Jones' },
    { id: '5', username: 'mike_brown', email: 'mike@example.com', fullName: 'Mike Brown' }
];

module.exports = users;